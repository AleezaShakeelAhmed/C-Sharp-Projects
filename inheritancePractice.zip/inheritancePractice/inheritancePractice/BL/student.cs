﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritancePractice.BL
{
    class student
    {
        protected string name;
        protected string session;
        protected bool isDayScholar;
        protected int EntryTestMarks;
        protected int HSMarks;

        public string getName()
        {
            return name;
        }

        public void setName(string name)
        {
            this.name = name;
        }
        public string getsession()
        {
            return session;
        }
        public void setsession(string session)
        {
            this.session = session;
        }
        public bool getisdayscholer()
        {
            return isDayScholar;
        }
        public void setisdayscholer(bool isDayScholar)
        {
            this.isDayScholar = isDayScholar;
        }
        public int getentrytestmarks()
        {
            return EntryTestMarks;
        }
        public void setentrytestmarks(int EntryTestMarks)
        {
            this.EntryTestMarks = EntryTestMarks;
        }
        public int gethsmarks()
        {
            return HSMarks;
        }
        public void sethamarks(int HSMarks)
        {
            this.HSMarks = HSMarks;
        }

        public double calculateMerit()
        {
            double merit = 0.0;
            // Code to calculate merit
            return merit;
        }
    }

}
