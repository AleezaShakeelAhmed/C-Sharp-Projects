﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using inheritancePractice.BL;

namespace inheritancePractice
{
    class Program
    {
        static void Main(string[] args)
        {
            hostellite std = new hostellite();
            std.setName("Leezu");
            string name = std.getName();
            Console.WriteLine("Name is " + name);
            Console.ReadKey();
        }
    }
}
